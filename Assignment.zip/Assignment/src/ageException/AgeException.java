package ageException;

import java.util.Scanner;

class CustomAgeException  extends Exception  
{  	
     //constructor converts the value into string
	public CustomAgeException (String str)  
    {  
        super(str);  
    }  
}  
public class AgeException 
{  
   
     public static void validate (int age) throws CustomAgeException{    
       if(age >20){  
   
        throw new CustomAgeException("Custome age exception");    
       } 
    }
   
    public static void main(String args[])  
    {  
        try  
        {   
        	int age;
        	Scanner sc=new Scanner(System.in);
        	//nextint- taking integer input
        	age=sc.nextInt();
            validate(age);  
        }  
        catch (CustomAgeException ex)  
        {  
            System.out.println("Caught the exception");  
     
            System.out.println("Exception occured: " + ex);  
        }  
  
        
    }  
}  