package ageException;

import java.util.Scanner;

//class using custom exception
public class AgeException extends Exception 
{  
      public AgeException(String string) {
		// TODO Auto-generated constructor stub
	}

	//method to check the age
     public static void validate (int age) throws AgeException{    
       if(age >20){  
        //throw an object of user defined exception
        throw new AgeException("Custom Exception");    
       } 
    }
   
    public static void main(String args[])  
    {  
        try  
        {   
        	int age;
        	Scanner sc=new Scanner(System.in);
        	System.out.println("Enter age:");
        	//nextint- taking integer input
        	age=sc.nextInt();
            validate(age);
            System.out.println("No exception");
        }  
        catch (AgeException ex)  
        {  
            System.out.println("Caught the exception");  
     
            System.out.println("Exception occured: " + ex);  
        }  
  
        
    }  
}  