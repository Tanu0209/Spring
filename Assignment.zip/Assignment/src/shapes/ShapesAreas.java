package shapes;

import java.util.Scanner;

interface Shape {
	double area();
}

class Rectangle implements Shape {

	private double length;
	private double breadth;

	public Rectangle(double length, double breadth) {
		this.length = length;
		this.breadth = breadth;
	}

	@Override
	public double area() {

		return length * breadth;
	}
}

class Circle implements Shape {

	private double radius;

	public Circle(double radius) {
		this.radius = radius;

	}

	@Override
	public double area() {

		return Math.PI * radius * radius;
	}
}

class Square implements Shape {

	private double side;

	public Square(double side) {
		this.side = side;

	}

	@Override
	public double area() {

		return side * side;
	}		
}

public class ShapesAreas{

	public static void main(String[] args) {
		
		String shape;
		Scanner sc = new Scanner(System.in);
		System.out.println("Type the shape name:");
	    shape = sc.nextLine();
	    
	    if(shape.equalsIgnoreCase("rectangle"))
	    {
     	double length = 2.0;
		double breadth = 3.0;
		Rectangle r = new Rectangle(length, breadth);

		System.out.println("Rectangle - Area: " + r.area());
	    }
	    if(shape.equalsIgnoreCase("circle"))
	    {
	    double radius = 2.0;
		Circle c = new Circle(radius);
		System.out.println("Circle - Area: " + c.area());
	    }
	    if(shape.equalsIgnoreCase("square"))
	    {
		double side = 45;
		Square s = new Square(side);
		System.out.println("Square - Area: " + s.area() );
	}
}
}

