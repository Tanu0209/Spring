package shapes;
import java.util.*;

public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Shape;
	    Scanner sc = new Scanner(System.in);
	    double area;
	   
	    System.out.println("Type the shape name:");
	    Shape = sc.nextLine();
	    //== is string pool cuz matches the address not the value
	    //ignore case matches value
	    if(Shape.equalsIgnoreCase("circle"))
	    {
	    	System.out.println("Enter radius");
	    	double radius;
	    	radius=sc.nextDouble();
	    	area=3.14*Math.pow(radius, 2);
	    	System.out.println("Area of circle "+area);
	    }
	    if(Shape.equalsIgnoreCase("rectangle"))
	    {
	    	System.out.println("Enter len of rectangle");
	    	double len;
	    	len=sc.nextDouble();
	    	System.out.println("Enter width of rectangle");
	    	double width;
	    	width=sc.nextDouble();
	    	area=len*width;
	    	System.out.println("Area of Rectangle "+ area);
	    }
		if(Shape.equalsIgnoreCase("square"))
		{
			System.out.println("Enter side of square");
			double side;
			side=sc.nextDouble();
			area=side*side;
			System.out.println("area of square "+area);
		}

	}

}
