package stringReverse;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
		String rev="";
		Scanner sc=new Scanner(System.in);
		
		str=sc.nextLine();
		
		int i=0,j=str.length()-1;
		int flag=1;
		while(i<j)
		{
			if(str.charAt(i)!=str.charAt(j))
			{
				flag=0;
				break;
			}
			else
			{
				i++;j--;
			}
		}
		if(flag==0)
		{
			System.out.println("Not palindrome");
		}
		else
		{
			System.out.println("palindrome");
		}

	}


	}


