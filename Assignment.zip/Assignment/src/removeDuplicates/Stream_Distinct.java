package removeDuplicates;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Stream_Distinct
{
	public static void main(String[] args)
	{
		// input list with duplicates
		List<Integer> list = new ArrayList<>(Arrays.asList(1, 10, 1, 2, 2, 3, 10, 3, 3, 4, 5, 5));
	
		System.out.println("ArrayList with duplicates: "+ list);

		// Construct a new list from the set constructed from elements of the list
		List<Integer> newList = list.stream().distinct().collect(Collectors.toList());

		//ArrayList with duplicates removed
		System.out.println("ArrayList with duplicates removed: "+ newList);
	}
}


 


