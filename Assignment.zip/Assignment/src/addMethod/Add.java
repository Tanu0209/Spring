package addMethod;
class StringAdd{
	 public  void add(String s1,String s2)
	 {
	 	System.out.println(s1.concat(s2));
	 }
}
class IntAdd {
	public void add(int num1,int num2)
	{
		System.out.println(num1+num2);
	}
	
}
public class Add {

public static void main(String [] args)
{
	StringAdd a = new StringAdd();
	a.add("fgg","fff");
	
	IntAdd b = new IntAdd();
	b.add(2,7);
	
}	

}
