package addMethod;

class Addition {	

	public int add(int a, int b, int c) {
		// TODO Auto-generated method stub
		int sum = a + b+ c;
		return sum;
	}

	public String concat(String string, String string2) {
		// TODO Auto-generated method stub
		String concat = string.concat(string2);
		return concat;
	}
}

class Add {
	public static void main(String[] args)
	{
		Addition ob = new Addition();
		 int sum2 = ob.add(34,78,98);
	        System.out.println(
	            "sum of the three integer value :" + sum2);
	        
	     String string3 = ob.concat("Hello","World");
	        System.out.println("Concatination of string is :"
	                           + string3);   

		
	}
}
