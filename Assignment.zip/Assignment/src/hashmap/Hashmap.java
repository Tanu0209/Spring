package hashmap;

import java.util.HashMap;

public class Hashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			HashMap<Integer, String> hash_map = new HashMap<Integer, String>();

			hash_map.put(10, "abc");
			hash_map.put(15, "xyz");
			hash_map.put(20, "qwe");
			hash_map.put(25, "opl");
			hash_map.put(30, "lmn");

			System.out.println("Initial Mappings are: " + hash_map);

			String removed_value = (String)hash_map.remove(15);

			System.out.println("Removed value is: "+ removed_value);
			
			System.out.println("New map is: "+ hash_map);
		}
		


	}


